<html xmlns="http://www.w3.org/1999/xhtml">  
   <head>  
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
      <title>Student Document</title>  
   </head>  
  
   <table border="1">  
      <tbody>  STUDENT DETAILS
         <tr>  
            <td>Student name</td>  
            <td>Student Age</td> 
            <td>Student Language</td> 
            <td>Student Address</td>  
         </tr>  
         <?php 
         foreach ($records as $row)  
         {  
            ?><tr>  
            <td><?php echo $row->name;?></td>  
            <td><?php echo $row->age;?></td>  
            <td><?php echo $row->language;?></td> 
            <td><?php echo $row->address;?></td> 
            </tr>  
         <?php }  
         ?>  
      </tbody>  
   </table>  
<a href="../../">Back to Enroll</a>
<body>  
</body>  
</html>