<!DOCTYPE html>  
<html>  
<head>  
    <title></title>  
</head>  
<body>  
    	<center><h3>Enroll Student</h3>
<br>

<form method="post" action="<?php echo base_url('index.php/main/do_upload'); ?>" enctype="multipart/form-data">
	
	
<div class="row">
<div class='form-group'>
<div class='col-md-3'>
<label>NAME : </label>
<input type="text" name="studentName" placeholder="enter your name" class="form-control">
</div>
</div>
</div>
<br>
<div class="row">
<div class='form-group'>
<div class='col-md-3'>
<label>AGE : </label>
<input type="text" name="age" placeholder="enter your age" class="form-control">
</div>
</div>
</div>
<br>
<div class="row">
<div class='form-group'>
<div class='col-md-3'>
<label>ADDRESS : </label>
<textarea name="address" placeholder="enter your address" class="form-control"></textarea>
</div>
</div>
</div>
<br>
<div class="row">
<div class='form-group'>
<div class='col-md-3'>
<label>LANGUAGE : </label>
<select name="language" class="form-control" required>
<option name="js">Tamil</option>
<option name="php">English</option>
<option name="ajax">Maths</option>
</select>	
</div>
</div>
</div>
<br>
<div class="row">
<div class='form-group'>
<div class='col-md-3'>
<label>PHOTO</label>
</div>
<div class='col-md-6'>
<input type="file" name="file" class="form-control">
</div>
</div>
</div>
<br>
<div class="col-md-3">
</div>
<div class="col-md-3">
<input type="submit" name="submit" class="btn btn-success" value="submit">
</div>
	
	</center>
</form>  
    
  
</body>  
</html>