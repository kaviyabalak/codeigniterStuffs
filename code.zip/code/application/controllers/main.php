<?php
 defined('BASEPATH') OR exit('No direct script access allowed');
class main extends CI_Controller {
public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
        }

    public function index()  
    {  
        $this->load->view('data');  

    }  
  public function do_upload(){
        if($this->input->post('submit'))
        {
                $this->load->model('data_model');           
                $config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                $this->upload->do_upload('file');

                $picture = $_FILES["file"]["name"];
                $studentData = array(
                'name'     => $this->input->post('studentName'),  
                'age'  => $this->input->post('age'),  
                'address'   => $this->input->post('address'),                      
                'language' => $this->input->post('language'),
                'photo' =>$picture
            );
            $studentDetails = $this->data_model->addStudentData($studentData);
            if(!empty($studentDetails)){
                 $students = $this->db->get('student');
                 $studentRecords['records'] =$students->result();
               $this->load->view('studentView',$studentRecords); 
            }
            else{
                echo "student record cannot be inserted";
            }

        }
    }
}
    ?>
