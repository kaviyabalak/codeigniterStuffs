<?php  
class Data_model extends CI_Model {  
  
		   function add_user( $user_data )
		{		   
		    $tbl = $this->db->dbprefix('project');
		    $this->db->insert($tbl, $user_data);
		    return !$this->db->affected_rows() == 0;
		}
		 function addStudentData($studentData)
		{	
		    $query = $this->db->insert('student', $studentData);
		    $lastId = $lastid=$this->db->insert_id();
		    return $lastId;
		}


    }  
  
?>